from biofilter.core import Biofilter
from biofilter.query.query_base import QueryBase

bf = Biofilter("mydb.sqlite")
q = QueryBase(bf.session)

# Explorar modelos
q.list_models()
q.describe_model("Gene")

# Acessar modelo dinamicamente
Gene = q.get_model("Gene")

# Criar sua própria consulta
stmt = select(Gene).where(Gene.symbol == "TP53")
genes = q.run_query(stmt, return_df=True)

print(genes)
