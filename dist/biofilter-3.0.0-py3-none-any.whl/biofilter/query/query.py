from sqlalchemy.orm import Session
from sqlalchemy import select, and_, or_, not_, func
from sqlalchemy.exc import SQLAlchemyError
import pandas as pd

# Import all models you want available in this base interface
from biofilter.db.models import (
    Entity, EntityName, EntityGroup, EntityRelationshipType,
    EntityRelationship,
    Gene, Variant, VariantGeneRelationship,
    ProteinMaster, ProteinPfam, ProteinPfamLink,
    GenomeAssembly, DataSource
    # Add more as needed
)


class Query:
    """
    Generic query interface for Biofilter3R.
    Provides helpers for model access, query execution, and inspection.
    """

    def __init__(self, session: Session):
        self.session = session
        self.select = select
        self.and_ = and_
        self.or_ = or_
        self.not_ = not_
        self.func = func

        self.models = {
            # Entity Models
            "Entity": Entity,
            "EntityName": EntityName,
            "EntityGroup": EntityGroup,
            "EntityRelationshipType": EntityRelationshipType,
            "EntityRelationship": EntityRelationship,

            "Gene": Gene,
            "Variant": Variant,
            "VariantGeneRelationship": VariantGeneRelationship,
            "ProteinMaster": ProteinMaster,
            "ProteinPfam": ProteinPfam,
            "ProteinPfamLink": ProteinPfamLink,
            "GenomeAssembly": GenomeAssembly,
            "DataSource": DataSource,
            # Extend this dictionary with more models as needed
        }

    def get_model(self, model_name: str):
        """Return a model class by name."""
        return self.models.get(model_name)

    def run_query(self, stmt, return_df: bool = False):
        """Execute a SQLAlchemy statement and return results."""
        try:
            result = self.session.execute(stmt).scalars().all()
            if return_df:
                df = pd.DataFrame([r.__dict__ for r in result])
                df.drop(columns=["_sa_instance_state"], errors="ignore", inplace=True)
                return df
            return result
        except SQLAlchemyError as e:
            print(f"Query failed: {e}")
            return []

    def raw_sql(self, sql: str):
        """Run a raw SQL string and return results."""
        try:
            return self.session.execute(sql).fetchall()
        except SQLAlchemyError as e:
            print(f"Raw SQL failed: {e}")
            return []

    def list_models(self):
        """List all registered models."""
        return list(self.models.keys())

    def describe_model(self, model_name: str):
        """Return column and relationship info for a given model."""
        model = self.get_model(model_name)
        if not model:
            print(f"Model '{model_name}' not found.")
            return None
        return {
            "columns": list(model.__table__.columns.keys()),
            "relationships": list(model.__mapper__.relationships.keys())
        }
