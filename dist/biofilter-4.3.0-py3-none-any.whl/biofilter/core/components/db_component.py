from __future__ import annotations

from pathlib import Path
from typing import Iterable, Literal, Optional

from biofilter.core.components.base_component import BaseComponent
from biofilter.modules.db.database import Database
from biofilter.modules.db.transfer import (
    backup_db,
    export_full_clone,
    import_full_clone,
    restore_db,
    verify_bundle,
)

ExportFormat = Literal["parquet", "csv"]


class DBComponent(BaseComponent):
    """
    Database lifecycle component.

    Owns the ONLY place where core.db is created/replaced.
    All other components must consume core.db via core.require_db().
    """

    def connect(self, new_uri: Optional[str] = None) -> Database:
        if new_uri:
            self.core.db_uri = new_uri

        # Idempotent fast-path:
        # many CLI commands instantiate Biofilter (which already connects in
        # the facade constructor) and then call bf.db.connect() again.
        # If we are already connected and URI is unchanged, just reuse it.
        if (
            new_uri is None
            and self.core.db is not None
            and getattr(self.core.db, "connected", False)
            and getattr(self.core.db, "engine", None) is not None
        ):
            return self.core.db

        self.core.db = Database(self.core.db_uri)

        return self.core.db

    def create_db(self, db_uri: Optional[str] = None, overwrite: bool = False):
        """
        Create a new database file/schema and connect to it.

        Note:
        - Uses Database().create_db(), which is expected to bootstrap
        core tables/mappings.
        """
        if db_uri:
            self.core.db_uri = db_uri

        # Create DB using your existing Database/CreateDBMixin logic.
        db = Database()  # do not pass uri in ctor
        db.db_uri = self.core.db_uri
        db.create_db(overwrite=overwrite)

        self.core.db = db

        self.core.logger.log(f"🏗️ Database created at: {self.core.db_uri}", "INFO")  # noqa E501
        return True

    def upgrade(self, *, seed_dir: str = "seed") -> bool:
        """
        Apply seeds to an existing database, idempotently.

        This used to run an Alembic upgrade first. There is no migration
        chain any more: a database is built once by create_db() with
        create_all, and a schema change produces a new bundle rather than
        an in-place migration (ADR-003 §2.8).

        Canonical entry point for `biofilter db upgrade`.
        """
        db = self.require_db()

        # Ensure engine/session are initialized
        # (connect if component was not connected yet)
        if not getattr(db, "engine", None):
            self.connect()

        # Seeds are an idempotent upsert, safe to run repeatedly.
        if not hasattr(db, "upgrade_db"):
            raise RuntimeError(
                "Database.upgrade_db() not found. "
                "Implement it in CreateDBMixin/Database before using DBComponent.upgrade()."   # noqa E501
            )

        db.upgrade_db(seed_dir=seed_dir)

        self.core.logger.log("✅ Seeds applied successfully.", "INFO")
        return True


    def bundle_id(self) -> Optional[str]:
        """Identifier of the bundle behind this connection, or None."""
        return self.require_db().bundle_id()

    def bundle_manifest(self) -> Optional[dict]:
        """Manifest of the bundle behind this connection, or None."""
        return self.require_db().bundle_manifest()

    def get_session(self):
        """
        Convenience passthrough to the shared Database session context manager.
        """
        return self.require_db().get_session()

    # ---------------------------
    # Snapshot (physical)
    # ---------------------------
    def backup(self, output_path: str | Path) -> Path:
        """
        Create a physical backup snapshot of the current DB.
        """
        db = self.core.require_db()
        if not db.engine:
            raise RuntimeError("Database engine not initialized. Connect first.")  # noqa E501

        out = Path(output_path).expanduser().resolve()
        self.core.logger.log(f"💾 Creating DB backup snapshot → {out}", "INFO")

        created = backup_db(db.engine, out)
        self.core.logger.log(f"✅ Backup created: {created}", "INFO")
        return created

    def restore(self, input_path: str | Path) -> None:
        """
        Restore a physical backup snapshot into the current DB target.
        """
        db = self.core.require_db()
        if not db.engine:
            raise RuntimeError("Database engine not initialized. Connect first.")  # noqa E501

        inp = Path(input_path).expanduser().resolve()
        self.core.logger.log(f"♻️ Restoring DB snapshot from → {inp}", "WARNING")  # noqa E501

        restore_db(db.engine, inp)
        self.core.logger.log("✅ Restore completed.", "INFO")

        # After restore, reconnect to ensure bootstrap_models is re-applied
        # and to avoid stale engine/session state.
        db.connect(check_exists=True)
        self.core.logger.log(
            "🔁 Reconnected after restore (bootstrapped models).", "INFO"
        )

    # ---------------------------
    # Full clone bundle (logical)
    # ---------------------------
    def export(
        self,
        out_dir: str | Path,
        *,
        fmt: ExportFormat = "parquet",
        biofilter_version: Optional[str] = None,
        schema_version: str = "unknown",
        chunksize: int = 250_000,
        tables: Iterable[str] | None = None,
        exclude_tables: Iterable[str] | None = None,
        include_partition_children: bool = False,
        checksums: bool = True,
    ) -> Path:
        """
        Export a logical full-clone bundle (manifest + one file per table).

        Partition children are skipped by default — the partitioned parent
        already carries their rows, so including both doubles the bundle.
        """
        db = self.core.require_db()
        if not db.engine:
            raise RuntimeError("Database engine not initialized. Connect first.")  # noqa E501

        out = Path(out_dir).expanduser().resolve()
        out.mkdir(parents=True, exist_ok=True)

        bf_ver = biofilter_version or getattr(self.core, "version", "unknown")

        self.core.logger.log(
            f"📦 Exporting full clone bundle → {out} (fmt={fmt})", "INFO"
        )

        bundle_dir = export_full_clone(
            db.engine,
            out,
            biofilter_version=bf_ver,
            schema_version=schema_version,
            fmt=fmt,
            chunksize=chunksize,
            include_tables=tables,
            exclude_tables=exclude_tables,
            include_partition_children=include_partition_children,
            checksums=checksums,
        )

        self.core.logger.log(f"✅ Bundle exported: {bundle_dir}", "INFO")
        return bundle_dir

    def verify(
        self, in_dir: str | Path, *, check_hashes: bool = True
    ) -> dict:
        """
        Validate a bundle against its manifest. Needs no DB connection.
        """
        report = verify_bundle(in_dir, check_hashes=check_hashes)
        if report["ok"]:
            self.core.logger.log(
                f"✅ Bundle OK: {report['tables_verified']}"
                f"/{report['tables_declared']} tables verified",
                "INFO",
            )
        else:
            self.core.logger.log(
                f"❌ Bundle has {len(report['problems'])} problem(s)",
                "ERROR",
            )
        return report

    def import_(
        self,
        in_dir: str | Path,
        *,
        fmt: ExportFormat = "parquet",
        rebuild_indexes: bool = True,
        reset_postgres_sequences: bool = True,
        allow_missing_tables: bool = False,
    ) -> None:
        """
        Import a logical full-clone bundle into the current DB schema.

        Expectations:
        - Schema already exists (created by create_db)
        - This will truncate all tables and re-insert preserving PKs.
        """
        db = self.core.require_db()
        if not db.engine:
            raise RuntimeError("Database engine not initialized. Connect first.")  # noqa E501

        inp = Path(in_dir).expanduser().resolve()
        self.core.logger.log(
            f"📥 Importing full clone bundle ← {inp} (fmt={fmt})", "WARNING"
        )

        import_full_clone(
            db=db,
            in_dir=inp,
            fmt=fmt,
            reset_sequences=reset_postgres_sequences,
            allow_missing_tables=allow_missing_tables,
        )

        self.core.logger.log("✅ Bundle import completed.", "INFO")

        # Re-bootstrap models (safe)
        # especially useful if import touched metadata-heavy tables
        db.connect(check_exists=True)

        if rebuild_indexes:
            # Reuse your existing index rebuild flow if available
            try:
                self.core.logger.log("🧱 Rebuilding indexes after import...", "INFO")  # noqa E501
                self.core.etl.rebuild_indexes(groups=None, drop_first=True)
                self.core.logger.log("✅ Index rebuild done.", "INFO")
            except Exception as e:
                self.core.logger.log(f"⚠️ Index rebuild failed: {e}", "WARNING")  # noqa E501
