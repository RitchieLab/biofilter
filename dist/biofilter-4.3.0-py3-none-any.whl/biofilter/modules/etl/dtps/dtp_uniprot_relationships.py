import os
from pathlib import Path

import pandas as pd

from biofilter.modules.db.models.model_entities import (  # noqa E501
    Entity,
    EntityAlias,
    EntityGroup,
    EntityRelationship,
    EntityRelationshipType,
)
from biofilter.modules.etl.mixins.base_dtp import DTPBase
from biofilter.modules.etl.mixins.entity_query_mixin import EntityQueryMixin

# TODO: GO esta vindo como listsa e preciso padronizar o processo,
# adicionamnaod um novo conjunto de indice para apenas o EntityRelationship


class DTP(DTPBase, EntityQueryMixin):
    def __init__(
        self,
        logger=None,
        debug_mode=False,
        datasource=None,
        package=None,
        session=None,
        db=None,
    ):  # noqa: E501
        self.logger = logger
        self.debug_mode = debug_mode
        self.data_source = datasource
        self.package = package
        self.session = session
        self.db = db

        # DTP versioning
        self.dtp_name = "dtp_uniprot_relationships"
        self.dtp_version = "1.1.0"
        self.compatible_schema_min = "4.0.0"
        self.compatible_schema_max = "4.2.0"

    # -------------------------------------------------------------------------
    #                            EXTRACT METHOD
    # -------------------------------------------------------------------------
    def extract(self, raw_dir: str):
        """
        This DTP is specifically for loading relationships from UniProt.
        It does not perform data extraction. To extract UniProt data, use the
        'uniprot' data source instead.
        """
        msg = (
            f"⚠️  The data source '{self.data_source.name}' is for relationships only. "  # noqa E501
            "Use the 'uniprot' data source to extract raw data."
        )
        self.logger.log(msg, "INFO")
        return True, msg, None

    # -------------------------------------------------------------------------
    #                            TRANSFORM METHOD
    # -------------------------------------------------------------------------
    def transform(self, raw_dir: str, processed_dir: str):
        """
        This DTP is specifically for loading relationships from UniProt.
        It does not perform data transformation. To transform UniProt data,
        use the 'uniprot' data source instead.
        """
        msg = (
            f"⚠️  The data source '{self.data_source.name}' is for relationships only. "  # noqa E501
            "Transformation should be done through the 'uniprot' data source."
        )
        self.logger.log(msg, "INFO")
        return True, msg

    # -------------------------------------------------------------------------
    #                            LOAD METHOD
    # -------------------------------------------------------------------------
    def load(self, processed_dir=None):
        """
        Load relationships between proteins and other entities from processed file.  # noqa: E501
        """
        msg = f"🔄 Loading relationships for data source '{self.data_source.name}'..."  # noqa E501

        self.logger.log(msg, "INFO")

        # Check Compartibility
        self.check_compatibility()

        total_relationships = 0
        total_warnings = 0
        parent_source = "uniprot"

        # READ PROCESSED DATA TO LOAD
        try:
            # Check if processed dir was set
            if not processed_dir:
                msg = "⚠️  processed_dir MUST be provided."
                self.logger.log(msg, "ERROR")
                return False, msg  # ⧮ Leaving with ERROR

            # The file is hosted in the parent dtp.
            processed_path = (
                Path(processed_dir)
                / self.data_source.source_system.name
                / parent_source  # noqa E501
            )  # noqa: E501
            processed_file_name = str(
                processed_path / "relationship_data.parquet"
            )  # noqa E501

            if not os.path.exists(processed_file_name):
                msg = f"⚠️  File not found: {processed_file_name}"
                self.logger.log(msg, "ERROR")
                return False, msg  # ⧮ Leaving with ERROR

            df = pd.read_parquet(processed_file_name, engine="pyarrow")

            if df.empty:
                msg = "DataFrame is empty."
                self.logger.log(msg, "ERROR")
                return False, msg

            df.fillna("", inplace=True)

        except Exception as e:
            msg = f"⚠️  Failed to try read data: {e}"
            self.logger.log(msg, "ERROR")
            return False, msg  # ⧮ Leaving with ERROR

        # Set DB and drop indexes
        try:
            self.db_write_mode()
            self.drop_indexes(self.get_entity_index_specs)
        except Exception as e:
            total_warnings += 1
            msg = f"⚠️  Failed to switch DB to write mode or drop indexes: {e}"
            self.logger.log(msg, "WARNING")
            return False, msg  # ⧮ Leaving with ERROR

        # GET ENTITY GROUP ID AND OMICS STATUS
        try:
            self.get_entity_group("Proteins")
        except Exception as e:
            msg = f"Error on DTP to get Entity Group: {e}"
            return False, msg  # ⧮ Leaving with ERROR

        # Map entity groups and relationship types to their IDs
        try:
            # Load in memory all entity groups to avoid multiple queries
            group_map = {
                g.name.lower(): g.id
                for g in self.session.query(EntityGroup).all()  # noqa E501
            }  # noqa E501
            # Load in memory all relationship types to avoid multiple queries
            rel_type_map = {
                rt.code.lower(): rt.id
                for rt in self.session.query(EntityRelationshipType).all()
            }  # noqa E501
        except Exception as e:
            msg = f"Error loading entity groups or relationship types: {e}"
            self.logger.log(msg, "ERROR")
            return False, msg

        try:
            # Transform the mapping to a Series with Int64 type (allows NaN)
            df["source_group_id"] = (
                df["source_type"].str.lower().map(group_map).astype("Int64")
            )  # noqa E501
            df["target_group_id"] = (
                df["target_type"].str.lower().map(group_map).astype("Int64")
            )  # noqa E501
            # Map relationship types to their IDs
            df["relation_type_id"] = (
                df["relation_type"]
                .str.lower()
                .map(rel_type_map)
                .astype("Int64")  # noqa E501
            )  # noqa E501
        except KeyError as e:
            msg = f"Error mapping group IDs or relationship types: {e}"
            self.logger.log(msg, "ERROR")
            return False, msg

        try:
            # Clean previous relationships from this data source
            deleted = (
                self.session.query(EntityRelationship)
                .filter_by(data_source_id=self.data_source.id)
                .delete(synchronize_session=False)
            )
            self.logger.log(
                f"🧹  Deleted {deleted} existing relationships from this data source"  # noqa E501
                "INFO",
            )  # noqa E501
            self.session.commit()

            # Reserve all relationships not loaded
            not_loaded = []

            for _, row in df.iterrows():
                target_ids = str(row["target_id"]).split("|")
                for target_id in target_ids:

                    # Get source entity
                    source_name = row["source_id"]
                    target_name = target_id
                    relation_type = row["relation_type_id"]
                    source_type = row["source_group_id"]
                    target_type = row["target_group_id"]

                    # Check values before processing
                    if (
                        pd.isna(row["relation_type_id"])
                        or pd.isna(row["source_id"])
                        or pd.isna(row["target_id"])
                    ):  # noqa E501
                        not_loaded.append(row)
                        msg = f"⚠️  Skipping: Missing required fields: {source_name} ➝ {target_name} - {relation_type}"  # noqa E501
                        self.logger.log(msg, "WARNING")
                        continue

                    # Get entity_1_id
                    source_entity = (
                        self.session.query(EntityAlias, Entity)
                        .join(Entity, Entity.id == EntityAlias.entity_id)
                        .filter(EntityAlias.alias_value == source_name)
                        .filter(Entity.is_active.is_(True))
                        .filter(Entity.group_id == source_type)
                        .first()
                    )
                    # Get entity_2_id
                    target_entity = (
                        self.session.query(EntityAlias, Entity)
                        .join(Entity, Entity.id == EntityAlias.entity_id)
                        .filter(EntityAlias.alias_value == target_name)
                        .filter(Entity.is_active.is_(True))
                        .filter(Entity.group_id == target_type)  # helper
                        .first()
                    )

                    if not source_entity or not target_entity:
                        not_loaded.append(row)
                        if self.debug_mode:
                            msg = f"⚠️  Skipping: Entity not found or group mismatch: {source_name} ➝ {target_name}"  # noqa E501
                            self.logger.log(msg, "WARNING")
                        continue

                    # TODO: check if exists a relationship already or add it in DB  # noqa E501
                    rel = EntityRelationship(
                        entity_1_id=source_entity.Entity.id,
                        entity_2_id=target_entity.Entity.id,
                        entity_1_group_id=source_type,
                        entity_2_group_id=target_type,
                        relationship_type_id=relation_type,
                        data_source_id=self.data_source.id,
                        etl_package_id=self.package.id,
                    )
                    self.session.add(rel)
                    total_relationships += 1

            # Commit batch
            try:
                self.session.commit()
                msg = f"✅ {total_relationships} relations loaded successfully"
                self.logger.log(msg, "INFO")
            except Exception as e:
                self.session.rollback()
                msg = f"❌ Error loading relations: {str(e)}"
                self.logger.log(msg, "ERROR")
                # return 0, load_status, msg

            # If there are relationships not loaded, save them in a DataFrame
            df_not_loaded = pd.DataFrame(not_loaded)

            if not df_not_loaded.empty:
                msg = f"⚠️ {len(df_not_loaded)} relationships not loaded due to some inconsistencies."  # noqa E501
                self.logger.log(msg, "WARNING")

                # Save the not loaded relationships to a CSV file
                not_loaded_path = (
                    processed_path / "relationship_data_not_loaded.csv"
                )  # noqa E501
                df_not_loaded.to_csv(not_loaded_path, index=False)

        except Exception as e:
            msg = f"KeyError during loading relationships: {e}"
            self.logger.log(msg, "ERROR")
            return False, msg

        # Set DB to Read Mode and Create Index
        try:
            self.create_indexes(self.get_entity_index_specs)
            self.db_read_mode()
        except Exception as e:
            total_warnings += 1
            msg = f"Failed to switch DB to write mode or drop indexes: {e}"
            self.logger.log(msg, "WARNING")

        if total_warnings != 0:
            msg = f"{total_warnings} warning to analysis in log file"
            self.logger.log(msg, "WARNING")

        msg = f"📥 Total Pathways: {total_relationships}"  # noqa E501  # noqa E501
        self.logger.log(msg, "INFO")

        return True, msg
